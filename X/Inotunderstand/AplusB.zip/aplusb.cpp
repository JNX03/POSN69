#include "aplusb.h"

void initialize(int N, int A[], int B[]) {
  return;
}

int answer_question(int i, int j) {
  return 0;
}

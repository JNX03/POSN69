#include "Georgette.h"

void answer(int N, int &mn, int &mx) {
  return;
}